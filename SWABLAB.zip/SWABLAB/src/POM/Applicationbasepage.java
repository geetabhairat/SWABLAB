package POM;

public class Applicationbasepage {
    protected static Homepage homepage;
    protected static Productpage productpage;
    protected static Product_details_page product_details_page;
    protected static Your_cart_page your_cart_page;
    protected static Your_information_page your_information_page;
    protected static  Overview_page overview_page;
    protected static Complete_page complete_page;
}
